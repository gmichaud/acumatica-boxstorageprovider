﻿using System;
using System.Web;
using PX.Data;
using PX.Web.Customization;
using PX.Web.UI;

[Customization.CstDesignMode(Disabled = true)]
public partial class Pages_SM_SM202630 : PXPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}